const Box = (props) => {
  //  Write your code here.
  <div></div>;
};

const element = (
  //  Write your code here.
  <div>
    <h1>dkk</h1>
    <Box />
    <Box />
    <Box />
  </div>
);

ReactDOM.render(element, document.getElementById("root"));
